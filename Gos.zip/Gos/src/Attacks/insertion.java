package Attacks;


import javax.swing.ImageIcon;


public class insertion extends Insertionsort{

	public selection(int Width, int level) {
		super(Width, level);
		this.setName("insertion");
		ImageIcon icon = new ImageIcon();
		this.setIcon(icon);
		this.setClassimage(icon.getImage());
	
		
	}
	public void insertBoss(int level) {
		int random = (int) ((Math.random() * lista.getLength()));
		int PosX = lista.getValue(random).getPosX();
		this.setBoss(random);
		TypeB Boss = new TypeB(PosX,level);
		lista.swap(Boss, random);
		this.setList(lista);
		this.age();
		
	public void age() {
		for (int i = 0; i< this.getList().getLength(); i++ ){
			int random;
			if (i != this.getBoss()) {
				random = (int) (Math.random() * 3);
			}else {
				random = (int) (Math.random() * 5);
			}
				Enemy aux = this.getList().getValue(i);
				aux.setResistance(random);
				aux.setResistanceInit(random);
				aux.setImages();
				aux.setImage(aux.getIcon().getImage());
				this.getList().swap(aux, i);
		}
	this.setBoss(this.getList().InsertionSort(this.getBoss()));
	this.setx();
	}
}

